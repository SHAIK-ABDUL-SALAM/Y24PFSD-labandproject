num = '10'
print(type(num))
converted_num = int(num)
print(type(converted_num))
print(converted_num + 20)