integer_input = int(input("Enter an integer: "))
float_value = float(integer_input)
print("Integer entered:", integer_input)
print("Converted float:", float_value)
