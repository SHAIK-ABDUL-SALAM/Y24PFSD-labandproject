string_value = input("Enter a string: ")
integer_value = int(input("Enter an integer: "))
result = str(integer_value) + string_value
print("Concatenation result:", result)
