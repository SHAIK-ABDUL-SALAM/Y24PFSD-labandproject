a = 8
a1 = format(a,'b')
print(a1)
a2 = format(a,'d')
print(a2)
a3 = format(a,'o')
print(a3)
