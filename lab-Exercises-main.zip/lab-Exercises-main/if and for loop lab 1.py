n = int(input("Enter the number:- "))
if n == 0:
    print("Wrong Input")
else:
    for i in range(n, n+1):
        val = n*(n*1)
        print(val)